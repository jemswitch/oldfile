<?php
$cats = get_post_meta( get_the_ID(), 'maxstore_masonry_cat', true );
if ( $cats ) {
	$count	 = count( $cats );
	?>
	<div class="masonry-loop">
		<?php
		$i		 = 0;
		foreach ( $cats as $key => $value ) {
			$term = get_term_by( 'id', $value, 'product_cat' );
			if ( $term ) {
				$term_name		 = $term->name;
				$term_id		 = $term->term_id;
				$term_slug		 = $term->slug;
				$desc			 = $term->description;
				$category_link	 = get_term_link( $term );
				$thumb_id		 = get_term_meta( $term_id, 'thumbnail_id', true );
				$term_img		 = wp_get_attachment_image( $thumb_id, 'maxstore-category' );
				?>
				<div class="masonry-entry masonry-id-<?php echo $i; ?>"> 
					<a href="<?php echo esc_url( $category_link ); ?>"> 
						<div class="top-grid-img">
							<?php
							if ( $term_img ) {
								echo $term_img;
							} else {
								echo '<img src="' . wc_placeholder_img_src() . '" alt="Placeholder" width="600px" height="600px" />';
							}
							?>
						</div>
						<div class="top-grid-heading">
							<h2>
								<?php
								if ( $term_name ) {
									echo esc_html( $term_name );
								}
								?>
							</h2>
							<p>
								<?php
								if ( $desc ) {
									echo substr( $desc, 0, 50 ), '&hellip;';
								}
								?>
							</p>
						</div>
					</a>
				</div>
				<?php
				$i++;
			}
		}
		?>
	</div>
	<?php
}
