<aside id="sidebar" class="col-md-<?php echo absint( get_theme_mod( 'right-sidebar-size', 3 ) ); ?> rsrc-right" role="complementary" itemscope itemtype="http://schema.org/WPSideBar">
	<?php dynamic_sidebar( 'maxstore-home-sidebar' ); ?>
</aside>
