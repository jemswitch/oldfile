<?php
$first_img				 = get_theme_mod( 'front_page_demo_banner_img', get_template_directory_uri() . '/template-parts/demo-img/demo-image-top.jpg' );
$first_img_title		 = get_theme_mod( 'front_page_demo_banner_title', __( 'MaxStore', 'maxstore' ) );
$first_img_desc			 = get_theme_mod( 'front_page_demo_banner_desc', __( 'Edit this section in customizer', 'maxstore' ) );
$first_img_button		 = __( 'View More', 'maxstore' );
$first_img_button_url	 = get_theme_mod( 'front_page_demo_banner_url', '#' );
$second_cat				 = get_terms( 'product_cat' );
if ( !empty( $second_cat ) && !is_wp_error( $second_cat ) ) {
	?> 
	<div class="top-area row no-gutter">       
		<div class="topfirst-img col-sm-6">     
			<div class="top-grid-img">
				<?php if ( $first_img ) { ?>  
					<img width="600" height="600" src="<?php echo esc_url( $first_img ); ?>" title="<?php echo esc_attr( $first_img_title ); ?>" alt="<?php echo esc_attr( $first_img_desc ); ?>"> 
				<?php } else { ?>  
					<img src="<?php echo wc_placeholder_img_src(); ?>" alt="Placeholder" width="600px" height="600px" />
				<?php } ?>  
			</div>
			<div class="top-grid-heading">
				<?php if ( $first_img_title != '' ) { ?>
					<h2>
						<?php echo esc_html( $first_img_title ); ?>
					</h2>
				<?php } ?>  
				<?php if ( $first_img_desc != '' ) { ?>
					<p>
						<?php echo esc_html( $first_img_desc ); ?>
					</p>
				<?php } ?> 
				<?php if ( $first_img_button_url != '' && $first_img_button != '' ) { ?>
					<p>                                      
					<div class="btn btn-primary btn-md outline">
						<a href="<?php echo esc_url( $first_img_button_url ); ?>">
							<?php echo esc_html( $first_img_button ); ?>
						</a>
					</div>                                  
					</p>
				<?php } ?>   
			</div>    
		</div>

		<div class="topsecond-img col-sm-6">
			<?php get_template_part( 'templates/template-part', 'home-cats-random' ); ?>
		</div>   
	</div>
<?php } ?>
