<h3 style="text-align: left;"><strong>OUR CATEGORIES</strong></h3>
<?php echo do_shortcode( '[product_categories number="4" parent="0"]' ); ?>
<h3><strong>MUST HAVE</strong></h3>
<?php echo do_shortcode( '[recent_products per_page="10" columns="5"]' ); ?>
<h3>SALE PRODUCTS</h3>
<?php echo do_shortcode( '[sale_products per_page="4"]' ); ?>
