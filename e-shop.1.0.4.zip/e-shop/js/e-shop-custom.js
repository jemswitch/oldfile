// Home slider
jQuery(document).ready(function( $ ) {
  $('#maxstore-slider').carousel();
}); 

