<?php
/**
 * The template used for displaying post content in single.php
 *
 * @package shop-isle
 */
?>
<?php
	/**
	 * @hooked shop_isle_post_header - 10
	 * @hooked shop_isle_post_meta - 20
	 * @hooked shop_isle_post_content - 30
	 */
	do_action( 'shop_isle_single_post' );
?>

